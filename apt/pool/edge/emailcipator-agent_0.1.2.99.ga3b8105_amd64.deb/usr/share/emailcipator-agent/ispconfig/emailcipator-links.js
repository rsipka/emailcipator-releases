// Emailcipator links into ISPConfig 3.3 (ADR 0060). Emailcipator serves this file at
// /ispconfig/emailcipator-links.js; install it on the panel as
// /usr/local/ispconfig/interface/web/js/js.d/emailcipator-links.js (readable by the web server);
// the panel's main page loads every script in js.d.
//
// Emailcipator links to a record as https://panel:8080/index.php#mail/mail_user_edit.php?id=38.
// ISPConfig itself has no such links: its main page always opens the start page of the session,
// and the form's own URL shows the form without the panel around it. This script reads the
// fragment once the panel has loaded its start page and opens the form the way the panel's own
// search does (ISPConfig.capp: switch to the module, load the form).
//
// Only the edit forms emailcipator links to are opened, each with a plain record number: the
// fragment must be exactly one of FORMS below followed by ?id=N. Anything else (another page of
// the panel, a delete or action page, extra parameters, encoded characters, another site) is
// left alone, and the panel's own permission checks apply as always. The list matches
// panelLink in internal/store/postgres/inventory.go (a test checks that).
(function () {
  "use strict";
  var FORMS = {
    "mail/mail_user_edit.php": "mail",
    "mail/mail_alias_edit.php": "mail",
    "mail/mail_forward_edit.php": "mail",
    "mail/mail_domain_catchall_edit.php": "mail",
    "mail/mail_domain_edit.php": "mail",
    "mail/mail_aliasdomain_edit.php": "mail",
    "mail/spamfilter_users_edit.php": "mail",
    "client/client_edit.php": "client",
    "client/reseller_edit.php": "client"
  };
  var link = /^#([a-z_\/]+\.php)\?id=([1-9][0-9]{0,8})$/;

  // the form and record of the fragment, or null when it is not one of ours
  function target() {
    var m = link.exec(window.location.hash);
    if (!m || !Object.prototype.hasOwnProperty.call(FORMS, m[1])) return null;
    return { module: FORMS[m[1]], page: m[1] + "?id=" + m[2] };
  }

  function open() {
    var t = target();
    if (!t || typeof ISPConfig === "undefined" || typeof ISPConfig.capp !== "function") return;
    // drop the fragment, so reloading the page shows the panel as usual
    window.history.replaceState(null, "", window.location.pathname + window.location.search);
    ISPConfig.capp(t.module, t.page);
  }

  // after the start page: the panel loads it into #pageContent with its own request; open the
  // form once that is there and no request is running (the start page would replace it), and
  // give up after 15 s
  function whenIdle() {
    if (!target()) return; // nothing to wait for
    var waited = 0;
    (function check() {
      var content = document.getElementById("pageContent");
      var busy = typeof jQuery !== "undefined" && jQuery.active > 0;
      if (content && content.children.length > 0 && !busy) {
        open();
      } else if ((waited += 100) < 15000) {
        window.setTimeout(check, 100);
      }
    })();
  }

  if (document.readyState === "complete") whenIdle();
  else window.addEventListener("load", whenIdle);
})();
